const ErrorCode={
    Success:200,
    Create:201,
    InternalServerError:500,
    BadRequest:401,
    NotFound:404
}


module.exports=ErrorCode